<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            {{-- Header --}}
            <div class="mb-6 flex justify-between items-center">
                <div>
                    <h2 class="text-3xl font-bold text-gray-800">Area Mitra</h2>
                    <p class="text-gray-500">Selamat datang, {{ Auth::user()->name }} ({{ $rental->nama_rental }})</p>
                </div>
                <span class="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
                    Status: {{ ucfirst($rental->status) }}
                </span>
            </div>

            {{-- Kartu Statistik --}}
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-blue-500">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100 text-blue-500 mr-4">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0"></path></svg>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Total Armada</p>
                            <p class="text-2xl font-bold text-gray-800">{{ $totalMobil }} Unit</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-yellow-500">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Pesanan Perlu Diproses</p>
                            <p class="text-2xl font-bold text-gray-800">{{ $pesananAktif }}</p>
                        </div>
                    </div>
                    <div class="mt-4 text-right">
                        <a href="{{ route('mitra.pesanan.index') }}" class="text-sm text-yellow-600 hover:text-yellow-800 font-medium">Lihat Pesanan &rarr;</a>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-green-500">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Total Pendapatan</p>
                            <p class="text-2xl font-bold text-gray-800">Rp {{ number_format($pendapatan, 0, ',', '.') }}</p>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Info Cabang --}}
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Aksi Cepat</h3>
                    <div class="flex gap-4">
                        <a href="{{ route('mitra.mobil.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150">
                            + Tambah Mobil Baru
                        </a>
                    </div>
                </div>

                {{-- AI Admin Assistant --}}
                <div class="bg-indigo-900 overflow-hidden shadow-xl sm:rounded-3xl p-6 text-white relative">
                    <div class="absolute top-0 right-0 p-8 opacity-10">
                        <i class="fa-solid fa-robot text-8xl"></i>
                    </div>
                    <div class="relative z-10">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                                <i class="fa-solid fa-wand-magic-sparkles text-indigo-300"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold">Asisten AI Mitra</h3>
                                <p class="text-xs text-indigo-200">Tanya seputar stok, kebijakan, atau saran operasional.</p>
                            </div>
                        </div>

                        <div id="admin-chat-box" class="h-32 overflow-y-auto mb-4 bg-black/20 rounded-2xl p-4 text-sm text-indigo-50 border border-white/10 hidden scrollbar-hide">
                            <div id="admin-chat-content"></div>
                        </div>

                        <div class="flex gap-2">
                            <input type="text" id="admin-question" placeholder="Misal: 'Bagaimana cara meningkatkan sewa?'" 
                                   class="flex-1 bg-white/10 border-white/20 rounded-xl text-sm placeholder-indigo-300 focus:ring-indigo-500 focus:border-indigo-500 text-white py-2.5">
                            <button id="btn-admin-assist" class="bg-white text-indigo-900 px-4 py-2 rounded-xl font-bold text-sm hover:bg-indigo-50 transition">
                                Tanya
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    @push('scripts')
    <script>
        const adminQuestion = document.getElementById('admin-question');
        const btnAdminAssist = document.getElementById('btn-admin-assist');
        const adminChatBox = document.getElementById('admin-chat-box');
        const adminChatContent = document.getElementById('admin-chat-content');

        function askAssistant() {
            const question = adminQuestion.value.trim();
            if (!question) return;

            btnAdminAssist.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
            btnAdminAssist.disabled = true;

            // Show chat box
            adminChatBox.classList.remove('hidden');
            adminChatContent.innerHTML += `<div class="mb-3 text-right"><span class="bg-white/10 px-3 py-1.5 rounded-lg inline-block font-medium">Mitra: ${question}</span></div>`;
            adminChatBox.scrollTop = adminChatBox.scrollHeight;
            adminQuestion.value = '';

            fetch("{{ route('mitra.admin_assist') }}", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ question: question })
            })
            .then(res => res.json())
            .then(res => {
                btnAdminAssist.innerHTML = 'Tanya';
                btnAdminAssist.disabled = false;

                const answer = res.answer || "Maaf, saya tidak bisa menjawab itu sekarang.";
                adminChatContent.innerHTML += `<div class="mb-3"><span class="text-indigo-300 font-bold block mb-1">AI Assistant:</span> ${answer}</div>`;
                adminChatBox.scrollTop = adminChatBox.scrollHeight;
            })
            .catch(err => {
                console.error(err);
                btnAdminAssist.innerHTML = 'Tanya';
                btnAdminAssist.disabled = false;
                adminChatContent.innerHTML += `<div class="mb-3 text-red-400">Terjadi kesalahan sistem.</div>`;
            });
        }

        btnAdminAssist.addEventListener('click', askAssistant);
        adminQuestion.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') askAssistant();
        });
    </script>
    @endpush
</x-app-layout>