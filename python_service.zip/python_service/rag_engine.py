import os
import re
import traceback
import json
import random
from difflib import SequenceMatcher
from flask import Flask, request, jsonify
from flask_cors import CORS
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings
from groq import Groq 
from dotenv import load_dotenv

# 1. INITIALIZATION
load_dotenv()
app = Flask(__name__)
CORS(app)

# Setup Groq
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# Setup ChromaDB
DB_DIR = "chroma_db"
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
vector_store = Chroma(persist_directory=DB_DIR, embedding_function=embeddings)

def normalize_text(text: str) -> str:
    t = (text or '').strip().lower()
    t = re.sub(r"[^\w\s]", " ", t, flags=re.UNICODE)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def get_fuzzy_city(text: str, available_cities: list[str], threshold: float = 0.6) -> str | None:
    t = normalize_text(text)
    if not t: return None
    
    # Cek match persis dulu
    for city in available_cities:
        if city.lower() in t:
            return city
            
    # Fuzzy match per kata
    words = t.split()
    best_city = None
    best_score = 0.0
    
    for word in words:
        if len(word) < 3: continue
        for city in available_cities:
            score = SequenceMatcher(None, word, city.lower()).ratio()
            if score > best_score:
                best_score = score
                best_city = city
                
    if best_score >= threshold:
        return best_city
    return None

def get_fuzzy_car(text: str, items: list[dict]) -> dict | None:
    t = normalize_text(text)
    if not t: return None
    
    # 1. Match persis (Innova Reborn -> Toyota Innova Reborn)
    for it in items:
        name = it['name'].lower()
        if t in name or name in t:
            return it
            
    # 2. Match kata kunci unik (Reborn, Xenia, Sigra, dll) 
    skip_words = ["mobil", "sewa", "rental", "mau", "toyota", "daihatsu", "honda", "suzuki", "mitsubishi", "nissan", "wuling", "hyundai"]
    words = [w for w in t.split() if len(w) > 3 and w not in skip_words]
    for word in words:
        for it in items:
            if word in it['name'].lower():
                return it
            
    # 3. Fuzzy match per kata (difflib)
    best_item = None
    best_score = 0.0
    for it in items:
        score = SequenceMatcher(None, t, it['name'].lower()).ratio()
        if score > best_score:
            best_score = score
            best_item = it
                
    if best_score >= 0.5:
        return best_item
    return None

def detect_date(text: str) -> str | None:
    t = normalize_text(text)
    months = ["januari", "februari", "maret", "april", "mei", "juni", "juli", "agustus", "september", "oktober", "november", "desember",
              "jan", "feb", "mar", "apr", "mei", "jun", "jul", "agu", "sep", "okt", "nov", "des"]
    
    # Cek format tanggal (misal: 20 april)
    date_pattern = r'(\d{1,2})\s+(' + '|'.join(months) + r')'
    match = re.search(date_pattern, t)
    if match:
        return f"{match.group(1)} {match.group(2)}"
    
    # Cek angka saja (misal: tanggal 20)
    if any(k in t for k in ["tanggal", "tgl", "tgl ", "tanggal "]):
        match_digit = re.search(r'\d{1,2}', t)
        if match_digit:
            return f"tanggal {match_digit.group(0)}"
            
    return None

def detect_passenger_count(text: str) -> int | None:
    t = normalize_text(text)
    
    # cari angka langsung
    match = re.search(r'\b(\d{1,2})\s*(orang|org|penumpang)?\b', t)
    if match:
        return int(match.group(1))
    
    # mapping kata umum
    if "berdua" in t: return 2
    if "bertiga" in t: return 3
    if "berempat" in t: return 4
    if "berlima" in t: return 5
    
    return None

def parse_stock_items(context: str) -> list[dict]:
    if 'DATA STOK MOBIL SAAT INI' not in context:
        return []
    try:
        # Ambil bagian setelah header stok
        stock_section = context.split('DATA STOK MOBIL SAAT INI', 1)[1]
        # Split per baris dan bersihkan
        lines = [ln.strip() for ln in stock_section.splitlines() if '|' in ln]
        
        items: list[dict] = []
        for ln in lines:
            # Bersihkan prefix seperti '- ID:', '* ID:', dll
            clean_ln = re.sub(r"^[*\-\s]+", "", ln).strip()
            parts = [p.strip() for p in clean_ln.split('|')]
            if not parts: continue
            
            details = {}
            for p in parts:
                if ':' in p:
                    key_val = p.split(':', 1)
                    key = key_val[0].strip().upper()
                    val = key_val[1].strip()
                    
                    # Map keys consistently
                    if key == 'ID': details['id'] = val
                    elif key in ('UNIT', 'NAMA'): details['name'] = val
                    elif key in ('CABANG', 'KOTA'): details['kota'] = val
                    elif key == 'HARGA': details['harga'] = val
                    elif key == 'TRANSMISI': details['transmisi'] = val
                    elif key == 'TIPE': details['tipe'] = val
                    elif key == 'KURSI': details['kursi'] = val
                    elif key == 'BBM': details['bbm'] = val
                    elif key == 'MITRA': details['mitra'] = val
            
            if 'name' in details and 'kota' in details:
                items.append(details)
        return items
    except Exception as e:
        print(f"Error parsing stock: {e}")
        return []

# ============================================================
# RAG RETRIEVAL FUNCTIONS
# ============================================================

def retrieve_car_knowledge(query: str, rental_id: str, top_k: int = 5) -> dict:
    """
    Melakukan RAG retrieval dari ChromaDB untuk mendapatkan pengetahuan tentang mobil.
    Mengembalikan dict berisi konteks dan metadata retrieval.
    """
    rag_result = {
        "context": "",
        "docs_retrieved": 0,
        "scores": [],
        "sources": []
    }
    
    try:
        # --- RETRIEVAL 1: Pengetahuan Mobil (Global) ---
        # Cari dokumen car_knowledge yang relevan secara semantik
        knowledge_results = vector_store.similarity_search_with_relevance_scores(
            query, 
            k=top_k, 
            filter={"doc_type": "car_knowledge"}
        )
        
        knowledge_docs = []
        for doc, score in knowledge_results:
            if score > 0.3:  # Threshold relevance
                knowledge_docs.append(doc.page_content)
                rag_result["scores"].append(round(score, 3))
                rag_result["sources"].append(f"car_knowledge (score={score:.3f})")
        
        # --- RETRIEVAL 2: Spesifikasi Mobil dari DB ---
        # Cari dokumen car_spec yang relevan
        spec_results = vector_store.similarity_search_with_relevance_scores(
            query,
            k=3,
            filter={"doc_type": "car_spec"}
        )
        
        spec_docs = []
        for doc, score in spec_results:
            if score > 0.3:
                spec_docs.append(doc.page_content)
                rag_result["scores"].append(round(score, 3))
                rag_result["sources"].append(f"car_spec (score={score:.3f})")
        
        # --- GABUNGKAN HASIL ---
        all_contexts = []
        if knowledge_docs:
            all_contexts.append("PENGETAHUAN MOBIL (dari Knowledge Base):\n" + "\n".join(knowledge_docs))
        if spec_docs:
            all_contexts.append("SPESIFIKASI UNIT (dari Database):\n" + "\n".join(spec_docs))
            
        rag_result["context"] = "\n\n".join(all_contexts)
        rag_result["docs_retrieved"] = len(knowledge_docs) + len(spec_docs)
        
    except Exception as e:
        print(f"[RAG] Error during car knowledge retrieval: {e}")
    
    return rag_result


def retrieve_policy_knowledge(query: str, rental_id: str) -> str:
    """
    Melakukan RAG retrieval untuk FAQ/kebijakan rental.
    """
    try:
        # Coba cari policy spesifik rental dulu
        results = vector_store.similarity_search_with_relevance_scores(
            query, k=3, 
            filter={"rental_id": str(rental_id)}
        )
        
        docs = [doc.page_content for doc, score in results if score > 0.4]
        
        # Jika tidak ada hasil spesifik rental, coba cari global
        if not docs:
            results = vector_store.similarity_search_with_relevance_scores(
                query, k=3,
                filter={"doc_type": "policy"}
            )
            docs = [doc.page_content for doc, score in results if score > 0.4]
        
        return "\n".join(docs) if docs else ""
    except Exception as e:
        print(f"[RAG] Error during policy retrieval: {e}")
        return ""


@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_input = data.get('question', '')
        user_name = data.get('user_name')
        laravel_context = data.get('context', '')
        rental_id = str(data.get('rental_id', '1'))
        raw_history = data.get('history', [])

        user_input_norm = normalize_text(user_input)
        if len(user_input_norm) < 2:
            return jsonify({"answer": "Maaf, bisa diperjelas lagi pertanyaannya?"})

        # 1. PARSE CONTEXT & DATA (BACKEND CONTROL)
        try:
            cities_raw = laravel_context.split('DATA KOTA YANG TERSEDIA DI RENTAL INI:')[1].split('DATA STOK MOBIL SAAT INI')[0].strip()
            available_cities = [c.strip() for c in cities_raw.split(',') if c.strip() and c.strip().lower() not in ('tidak ada cabang', '')]
        except:
            available_cities = []
        
        items = parse_stock_items(laravel_context)

        items_dump = json.dumps([
            {"id": it.get('id', ''),
             "nama": it.get('name', ''), 
             "kota": it.get('kota', ''),
             "transmisi": it.get('transmisi', ''), 
             "kursi": it.get('kursi', ''), 
             "harga": f"Rp {str(it.get('harga', '')).replace('Rp', '').replace('rp', '').replace('/hari', '').strip()}/hari"} 
            for it in items
        ])

        # ============================================================
        # 2. RAG RETRIEVAL — AKTIF UNTUK SEMUA PERTANYAAN TERKAIT MOBIL
        # ============================================================
        rag_car_context = ""
        rag_policy_context = ""
        rag_metadata = {"car_docs": 0, "policy_docs": 0, "scores": []}
        
        # Deteksi apakah pertanyaan terkait mobil/rekomendasi
        car_keywords = ['mobil', 'sewa', 'rental', 'booking', 'cari', 'rekomendasi', 'recommend',
                        'keluarga', 'irit', 'murah', 'mewah', 'besar', 'kecil', 'nyaman',
                        'orang', 'penumpang', 'kursi', 'adventure', 'touring', 'liburan',
                        'wedding', 'acara', 'wisata', 'tour', 'matic', 'manual', 'suv', 'mpv',
                        'avanza', 'innova', 'xpander', 'pajero', 'fortuner', 'alphard', 'hiace',
                        'agya', 'ayla', 'sigra', 'calya', 'xenia', 'terios', 'rocky', 'brio',
                        'rush', 'zenix', 'budget', 'hemat', 'premium', 'vip', 'solo', 'pasangan',
                        'rombongan', 'group', 'mudik', 'luar kota', 'dalam kota', 'off road',
                        'daftar', 'list', 'tampilkan', 'tersedia', 'ada', 'pilih', 'harga']
        
        is_car_related = any(w in user_input_norm for w in car_keywords)
        
        # Deteksi FAQ/kebijakan
        faq_keywords = ['syarat', 'denda', 'aturan', 'kebijakan', 'sopir', 'lepas kunci', 
                        'jaminan', 'bayar', 'ketentuan', 'cancel', 'batal', 'telat', 'terlambat']
        is_faq_related = any(w in user_input_norm for w in faq_keywords)
        
        # --- RAG RETRIEVAL: MOBIL ---
        if is_car_related:
            print(f"\n[RAG] [SEARCH] Car knowledge retrieval for: \"{user_input[:80]}\"")
            rag_car = retrieve_car_knowledge(user_input, rental_id)
            rag_car_context = rag_car["context"]
            rag_metadata["car_docs"] = rag_car["docs_retrieved"]
            rag_metadata["scores"] = rag_car["scores"]
            print(f"[RAG] [OK] Retrieved {rag_car['docs_retrieved']} car knowledge docs")
            for src in rag_car["sources"]:
                print(f"[RAG]    └─ {src}")
        
        # --- RAG RETRIEVAL: KEBIJAKAN ---
        if is_faq_related:
            print(f"\n[RAG] [POLICY] Policy retrieval for: \"{user_input[:80]}\"")
            rag_policy_context = retrieve_policy_knowledge(user_input, rental_id)
            if rag_policy_context:
                rag_metadata["policy_docs"] = len(rag_policy_context.split('\n'))
                print(f"[RAG] [OK] Retrieved policy context ({len(rag_policy_context)} chars)")
        
        total_rag_docs = rag_metadata["car_docs"] + rag_metadata["policy_docs"]
        print(f"[RAG] [STATS] Total RAG documents used this turn: {total_rag_docs}")

        # ============================================================
        # 3. CONSTRUCT SYSTEM PROMPT (DENGAN RAG CONTEXT)
        # ============================================================
        styles = [
            "Informasi langsung: Tegas, jelas, dan fokus pada rincian. Dilarang menggunakan kalimat pengantar basa-basi.",
            "Tegas & Ringkas: Sangat to-the-point. DILARANG KERAS membuat kalimat retoris seperti 'Mencari mobil?' di awal kalimat.",
            "Singkat: Merespon dengan jumlah kata seminimal mungkin tanpa menghilangkan konteks."
        ]
        chosen_style = random.choice(styles)

        # Bangun bagian RAG context untuk prompt
        rag_section = ""
        if rag_car_context:
            rag_section += f"""
KONTEKS RAG — PENGETAHUAN MOBIL (Hasil Retrieval dari Knowledge Base):
{rag_car_context}

INSTRUKSI RAG: Gunakan pengetahuan di atas untuk memberikan REKOMENDASI yang sesuai kebutuhan user. 
Jika user menyebut kebutuhan spesifik (misal: keluarga, irit, mewah, rombongan), 
PRIORITASKAN mobil yang cocok berdasarkan konteks RAG, lalu cocokkan dengan DATA REAL-TIME di bawah.
"""
        
        if rag_policy_context:
            rag_section += f"""
KONTEKS RAG — KEBIJAKAN & KETENTUAN (Hasil Retrieval dari Knowledge Base):
{rag_policy_context}

INSTRUKSI: Jawab pertanyaan kebijakan berdasarkan konteks di atas. Singkat, maks 3 kalimat.
"""

        system_prompt = f"""Kamu adalah asisten platform rental mobil multi-kota yang didukung oleh sistem RAG (Retrieval-Augmented Generation).

IDENTITAS & BATASAN:
- Sistem melayani banyak kota.
- HANYA jawab hal yang berkaitan dengan rental mobil.
- JIKA user menyebutkan kota yang TIDAK ADA, beritahu dengan sopan.

ALUR PERCAKAPAN (KAMU YANG MENENTUKAN):
- Kamu harus membaca riwayat percakapan untuk memahami niat (intent) user.
- Jika user mencari mobil tapi belum menyebutkan kota, TANYAKAN KOTA. Jangan tampilkan daftar.
- Jika user meminta daftar mobil di kota tertentu, TAMPILKAN DAFTAR MOBIL HANYA untuk kota tersebut.
- Jika user sudah memilih mobil, tanyakan TANGGAL PEMAKAIAN (jika belum menyebutkan).
- Jika user merespons "iya", "lanjut", atau setuju untuk melihat mobil, tampilkan daftarnya sesuai kota.
- Jika user membatalkan (cth: "tidak jadi", "ganti kota"), lupakan pilihan sebelumnya dan ikuti alur baru.
- Jika user SUDAH FIX memilih KOTA, MOBIL, dan TANGGAL: berikan konfirmasi akhir dan WAJIB set is_ready menjadi true dalam JSON.

REKOMENDASI BERBASIS RAG:
- Jika user menyebut KEBUTUHAN (misal: "keluarga", "irit", "mewah", "rombongan", "liburan", "wedding"),
  gunakan KONTEKS RAG di bawah untuk menentukan mobil mana yang PALING COCOK.
- Sebutkan ALASAN singkat mengapa mobil tersebut direkomendasikan (misal: "7 kursi, cocok untuk keluarga").
- Urutkan rekomendasi dari yang PALING SESUAI kebutuhan user.
- HANYA rekomendasikan mobil yang ADA di DATA REAL-TIME (jangan rekomendasikan mobil yang stoknya habis).

GAYA BAHASA & TONE:
- Terapkan gaya bahasa berikut untuk responsmu kali ini: "{chosen_style}"
- Gunakan bahasa Indonesia yang profesional dan natural.
- Dilarang keras menggunakan sapaan seperti "Kak", "Bro", "Sis", dll.
- DILARANG MERANGKAI KALIMAT PENGANTAR/BASA-BASI (seperti: "Anda mencari mobil hemat di...", "Tentu saja...", "Berikut adalah..."). LANGSUNG ke inti poin atau daftar mobil.
- Jika informasi kurang (misal kota belum ada), tanya langsung dan singkat.

FORMAT MENAMPILKAN DAFTAR MOBIL:
- WAJIB gunakan format list bernomor (1, 2, 3, dst).
- WAJIB sebutkan NAMA MOBIL terlebih dahulu, baru diikuti harganya.
- Jika ada rekomendasi RAG, tambahkan keterangan singkat kecocokan.
- Format baku: 1. [Nama Mobil] - Rp [Harga]/hari (keterangan kecocokan jika ada)

CONTOH RESPON:
User: "saya ingin melihat mobil"
→ "Anda ingin melihat mobil di kota mana?"
User: "butuh mobil keluarga 7 orang di pekanbaru"
→ "Rekomendasi mobil keluarga 7 kursi di Pekanbaru:\\n1. Innova Reborn - Rp 550.000/hari (MPV premium, nyaman untuk keluarga besar)\\n2. Xpander - Rp 450.000/hari (MPV modern, kabin luas)\\n3. Avanza - Rp 300.000/hari (MPV kompak, pilihan ekonomis)"
{rag_section}
DATA KOTA TERSEDIA:
{", ".join(available_cities) if available_cities else 'Belum ada data'}

DATA MOBIL REAL-TIME (DARI DATABASE — HANYA GUNAKAN INI UNTUK KETERSEDIAAN & HARGA):
{items_dump}

FORMAT OUTPUT (WAJIB JSON):
{{
  "intent": "greeting | ask_city | show_list | recommend | ask_date | booking_ready | cancel | faq | other",
  "rag_used": true/false,
  "booking_details": {{
      "is_ready": false,
      "car_id": "ISI_ID_MOBIL_DARI_DATA",
      "date": "ISI_TANGGAL_YANG_DIMINTA"
  }},
  "response": "Seluruh teks jawaban ke user. PENTING: Jika ada daftar mobil, DAFTAR TERSEBUT WAJIB DIGABUNG KE DALAM STRING INI JUGA menggunakan \\\\n. DILARANG MEMBUAT KEY ARRAY BARU."
}}"""

        messages = [{"role": "system", "content": system_prompt}]
        for h in raw_history[-5:]:
            if isinstance(h, dict):
                if h.get('user'): messages.append({"role": "user", "content": h['user']})
                if h.get('bot'): messages.append({"role": "assistant", "content": h['bot']})
        messages.append({"role": "user", "content": user_input})

        # 4. LLM INTERPRETATION
        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=messages,
            temperature=0.2,
            response_format={"type": "json_object"}
        )

        res_ai = {}
        try:
            res_ai = json.loads(completion.choices[0].message.content)
            final_answer = res_ai.get("response", "Ada yang bisa saya bantu?")
        except:
            final_answer = "Maaf, bisa diulangi lagi?"

        # Log apakah LLM melaporkan menggunakan RAG
        if res_ai.get("rag_used"):
            print(f"[RAG] [BOT] LLM reported using RAG context for this response (intent: {res_ai.get('intent', 'unknown')})")

        # --- SOFT GUARDRAIL (MEMASTIKAN FORMAT LIST BERHASIL DIBUAT) ---
        if "Rp" in final_answer and "-" in final_answer:
            lines = final_answer.split("\n")
            numbered = []
            i = 1
            has_bullet = False
            for ln in lines:
                if ln.strip().startswith("-"):
                    clean = ln.lstrip("-").strip()
                    numbered.append(f"{i}. {clean}")
                    i += 1
                    has_bullet = True
                else:
                    numbered.append(ln)
            if has_bullet:
                final_answer = "\n".join(numbered)

        # --- GENERATE BOOKING LINK (PURE LLM INTENT) ---
        booking_details = res_ai.get("booking_details", {})
        if booking_details.get("is_ready") and booking_details.get("car_id") and booking_details.get("date"):
            car_id = booking_details.get("car_id")
            date_val = booking_details.get("date")
            final_answer += f"<br><br>[LINK_BOOKING:{car_id}|{date_val}]"

        # --- FAQ/POLICY HANDLING (RAG) — Jika ada konteks policy, gunakan LLM kedua ---
        if is_faq_related and rag_policy_context:
            try:
                faq_completion = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {"role": "system", "content": f"Jawab singkat, natural, dan membantu (maks 3 kalimat) berdasarkan info ini:\n{rag_policy_context}"},
                        {"role": "user", "content": user_input}
                    ],
                    temperature=0.1
                )
                final_answer = faq_completion.choices[0].message.content
                print(f"[RAG] [OK] FAQ answered using RAG policy context")
            except: pass

        final_answer = final_answer.replace('\n', '<br>')
        return jsonify({"answer": final_answer})

    except Exception as e:
        print(traceback.format_exc())
        return jsonify({"answer": "Maaf, ada kendala teknis sedikit. Bisa coba ulangi lagi?"}), 200


@app.route('/search', methods=['POST'])
def search():
    """
    Endpoint untuk Smart Search / Pencarian Cerdas.
    Menerima query bahasa alami dan mengembalikan rekomendasi mobil.
    """
    try:
        data = request.json
        query = data.get('query', '')
        laravel_context = data.get('context', '')
        rental_id = str(data.get('rental_id', '1'))

        if not query:
            return jsonify({"recommendations": []})

        # 1. RAG Retrieval untuk mencari mobil yang cocok dengan kebutuhan
        rag_car = retrieve_car_knowledge(query, rental_id, top_k=3)
        rag_context = rag_car["context"]

        # 2. Parse stok real-time dari Laravel context
        items = parse_stock_items(laravel_context)
        items_dump = json.dumps([
            {"id": it.get('id', ''), "nama": it.get('name', ''), "harga": it.get('harga', ''), "kota": it.get('kota', '')} 
            for it in items
        ])

        # 3. Gunakan LLM untuk meranking dan memilih mobil terbaik dari stok berdasarkan pengetahuan RAG
        prompt = f"""Tugasmu adalah melakukan SMART SEARCH untuk penyewaan mobil.
User mencari mobil dengan kriteria: "{query}"

KONTEKS PENGETAHUAN (RAG):
{rag_context}

DATA STOK REAL-TIME (Pilih HANYA dari sini):
{items_dump}

INSTRUKSI:
- Analisis kebutuhan user berdasarkan query dan konteks RAG serta DATA STOK.
- Berikan satu paragraf deskripsi (summary) yang ramah dan membantu yang menjawab langsung query pengguna (misal: "Berikut adalah pilihan mobil keluarga yang cocok untuk Anda di Pekanbaru...").
- Pilih maksimal 3 mobil dari DATA STOK REAL-TIME yang paling cocok untuk direkomendasikan.
- Berikan alasan singkat (reason) untuk setiap mobil yang dipilih.
- Jika tidak ada yang cocok, jelaskan di summary dan kosongkan recommendations.

FORMAT OUTPUT (JSON):
{{
  "summary": "Paragraf ringkasan cerdas yang menjawab kriteria pencarian...",
  "recommendations": [
    {{
      "id": "ID_MOBIL",
      "reason": "Alasan singkat (maks 10 kata)"
    }},
    ...
  ]
}}"""

        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role": "system", "content": prompt}],
            temperature=0.1,
            response_format={"type": "json_object"}
        )

        res = json.loads(completion.choices[0].message.content)
        return jsonify(res)

    except Exception as e:
        print(traceback.format_exc())
        return jsonify({"summary": "Maaf, terjadi kesalahan saat melakukan pencarian cerdas.", "recommendations": [], "error": str(e)}), 500


@app.route('/admin-assist', methods=['POST'])
def admin_assist():
    """
    Endpoint untuk Assistant Admin.
    Membantu admin mengelola rental, menjawab pertanyaan tentang stok, atau kebijakan.
    """
    try:
        data = request.json
        question = data.get('question', '')
        laravel_context = data.get('context', '') # Berisi data transaksi, stok, dll khusus admin
        rental_id = str(data.get('rental_id', '1'))

        # Retrieval kebijakan/FAQ untuk membantu admin menjawab pertanyaan operasional
        rag_policy = retrieve_policy_knowledge(question, rental_id)

        prompt = f"""Kamu adalah Assistant Admin untuk platform rental mobil.
Tugasmu membantu pengelola rental (Mitra) dalam mengelola operasional mereka.

KONTEKS DATA RENTAL (Real-time):
{laravel_context}

KONTEKS KEBIJAKAN:
{rag_policy}

INSTRUKSI:
- Jawab pertanyaan admin dengan data yang ada.
- Berikan saran jika diminta (misal: "mobil mana yang paling sering disewa?").
- Gunakan bahasa yang profesional dan suportif.

PERTANYAAN ADMIN: "{question}"
"""

        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role": "system", "content": prompt}],
            temperature=0.3
        )

        return jsonify({"answer": completion.choices[0].message.content})

    except Exception as e:
        print(traceback.format_exc())
        return jsonify({"answer": "Maaf admin, ada gangguan pada sistem asisten."}), 500


if __name__ == "__main__":
    print("=" * 50)
    print("RAG Engine started with Car Knowledge Retrieval")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=False)
